package com.minor.minorclasssem6_225.Services;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Toast;

import com.minor.minorclasssem6_225.R;

public class ServiceboundActivity extends AppCompatActivity {

    MyBoundService boundService;
    boolean flag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicebound);

        Intent i2=new Intent(this,MyBoundService.class);
        bindService(i2,sc, Context.BIND_AUTO_CREATE);

        findViewById(R.id.servicestartbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

  String s=  boundService.mymsg1();
                Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.stopservicebtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
    ServiceConnection sc=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
                MyBoundService.MyBinder binder=(MyBoundService.MyBinder)service;
                  boundService=  binder.getService();
                 flag=true;

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            flag =false;
        }
    };
}
