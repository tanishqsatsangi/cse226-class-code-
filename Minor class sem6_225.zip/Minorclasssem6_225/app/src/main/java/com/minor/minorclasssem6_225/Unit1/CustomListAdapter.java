package com.minor.minorclasssem6_225.Unit1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class CustomListAdapter extends BaseAdapter {
    Context mcontext;
    ArrayList<PersonModel>personlist=new ArrayList<>();
    AlertDialog ad;

    public CustomListAdapter(Context context, ArrayList<PersonModel> al){
        mcontext=context;
        personlist=al;
    }

    @Override
    public int getCount() {
        return personlist.size();
    }

    @Override
    public Object getItem(int position) {
        return personlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
    View v=LayoutInflater.from(mcontext).inflate(R.layout.custom_listview_layout,null,false);
        ImageView ig=v.findViewById(R.id.img);
        TextView name=v.findViewById(R.id.personname);
        TextView details=v.findViewById(R.id.persondetails);
        Button delete=v.findViewById(R.id.delete);
        ig.setImageResource(personlist.get(position).getImg());
        name.setText(personlist.get(position).getName().toString());
        details.setText(personlist.get(position).getDescription().toString());
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder adb=new AlertDialog.Builder(mcontext);
               adb.setMessage("Do you want to delete the row?");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        personlist.remove(position);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ad.dismiss();
                    }
                });
                ad=adb.create();
                ad.show();

            }
        });
        return v;
    }
}
