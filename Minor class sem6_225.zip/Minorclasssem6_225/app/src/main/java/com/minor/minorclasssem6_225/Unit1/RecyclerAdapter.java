package com.minor.minorclasssem6_225.Unit1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.minor.minorclasssem6_225.R;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>{

    int n=10;
    Context mcontext;
    public RecyclerAdapter(Context context){
        mcontext=context;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.cardlayout,null,false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

        holder.delete.setVisibility(View.INVISIBLE);
        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
            holder.delete.setVisibility(View.VISIBLE);
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                        n--;
                        notifyDataSetChanged();
                }
            });
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return n;
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder{
        CardView cardView;
        ImageView delete;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView=itemView.findViewById(R.id.cardview);
            delete=itemView.findViewById(R.id.deletebtn);
        }
    }
}