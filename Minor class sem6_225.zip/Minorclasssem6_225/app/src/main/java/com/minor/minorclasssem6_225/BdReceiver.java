package com.minor.minorclasssem6_225;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.minor.minorclasssem6_225.background.BDDemoActivity;

public class BdReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        String state=intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if(state!=null){
            if(state.equals(TelephonyManager.EXTRA_STATE_RINGING)){
                String number=intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Toast.makeText(context, "ringing"+number, Toast.LENGTH_SHORT).show();
            }
            if(state.equals(TelephonyManager.EXTRA_STATE_IDLE)){
                String number=intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Toast.makeText(context, "idle"+number, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
