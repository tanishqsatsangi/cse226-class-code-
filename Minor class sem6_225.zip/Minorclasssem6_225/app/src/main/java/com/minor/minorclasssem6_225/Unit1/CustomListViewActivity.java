package com.minor.minorclasssem6_225.Unit1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class CustomListViewActivity extends AppCompatActivity {
    ArrayList<PersonModel> personlist=new ArrayList<>();

    ListView listView;
    EditText nameet,detailset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_view);
        listView=findViewById(R.id.listview_custom);
  /*      nameet=findViewById(R.id.name_et);
        detailset=findViewById(R.id.details_et);


        findViewById(R.id.addbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonModel ap=new PersonModel(nameet.getText().toString(),detailset.getText().toString(),R.drawable.ic_launcher_foreground);
                personlist.add(ap);
            }
        });
      findViewById(R.id.display).setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

              personlist.clear();


              CustomListAdapter adapter=new CustomListAdapter(CustomListViewActivity.this,personlist);

              listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                  @Override
                  public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                      view.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                  }
              });


          }
      });
*/
        for (int i=0;i<10;i++){
            PersonModel pm= new PersonModel("Tanishq"+i,"Student",R.drawable.ic_launcher_foreground);
            personlist.add(pm);
        }
        CustomListAdapter adapter=new CustomListAdapter(CustomListViewActivity.this,personlist);

        listView.setDividerHeight(5);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            view.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

        }
    });


    }
}
