package com.minor.minorclasssem6_225.background;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class RecyclerAsyncActivity extends AppCompatActivity {

    BrodcastReceiverdemo receiver;
    RecyclerView recyclerView;
    RecyclerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_async);
        recyclerView=findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2,LinearLayoutManager.VERTICAL));

    new Task().execute();

/*
        IntentFilter filter=new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
            registerReceiver(receiver,filter);
*/

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    class Task extends AsyncTask<Void,Integer,String>{
        ArrayList<Integer> al=new ArrayList<>();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(RecyclerAsyncActivity.this, "Starting", Toast.LENGTH_SHORT).show();
            adapter=new RecyclerAdapter(RecyclerAsyncActivity.this,R.drawable.ic_launcher_foreground,al);
            recyclerView.setAdapter(adapter);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(RecyclerAsyncActivity.this, ""+s, Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            adapter.notifyDataSetChanged();
        }

        @Override
        protected String doInBackground(Void... voids) {
            for(int i=0;i<20;i++){
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                al.add(i);
                publishProgress(i);
            }
            return "all added";

        }
    }
}
