package com.minor.minorclasssem6_225.background;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.Holder> {

    Context mcontext;
    int mimg;
    ArrayList<Integer> al=new ArrayList<>();
    public RecyclerAdapter(Context context, int img, ArrayList<Integer>arr){
        mcontext=context;
        al=arr;
        mimg=img; }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.bglistviewlatoyut,null,false);

        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.textView.setText(""+al.get(position));
        holder.img.setImageResource(R.drawable.ic_launcher_foreground);
            Log.i("axc",""+al.get(position));
    }

    @Override
    public int getItemCount() {
        return al.size();
    }

    class Holder extends RecyclerView.ViewHolder{
            ImageView img;
            TextView textView;
        public Holder(@NonNull View itemView) {
            super(itemView);
        img=itemView.findViewById(R.id.img);
        textView=itemView.findViewById(R.id.textview);
        }
    }
}
