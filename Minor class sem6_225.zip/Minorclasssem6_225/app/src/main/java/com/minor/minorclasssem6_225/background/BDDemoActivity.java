package com.minor.minorclasssem6_225.background;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.minor.minorclasssem6_225.BDRecyclerAdapter;
import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class BDDemoActivity extends AppCompatActivity {
RecyclerView rv;
BdReceiver1 receiver1;
    BDRecyclerAdapter adapter;
    ArrayList<String> al=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bddemo);
            rv=findViewById(R.id.recyclerphone);
            rv.setHasFixedSize(true);


        //to update data to list

        adapter=new BDRecyclerAdapter(BDDemoActivity.this,al);
        rv.setAdapter(adapter);

  if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)!= PackageManager.PERMISSION_GRANTED){
      ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_PHONE_STATE},1);
  }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if(requestCode==1){
        if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }
    }
public void update(String  s){
      al.add(s);
      adapter.notifyDataSetChanged();
}


public   class BdReceiver1 extends BroadcastReceiver {

        public BdReceiver1(){

    }
        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            String state=intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            if(state!=null){
                if(state.equals(TelephonyManager.EXTRA_STATE_RINGING)){
                    String number=intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                    Toast.makeText(context, "ringing"+number, Toast.LENGTH_SHORT).show();
               //     update(number);
                }
                if(state.equals(TelephonyManager.EXTRA_STATE_IDLE)){
                    String number=intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                    Toast.makeText(context, "idle"+number, Toast.LENGTH_SHORT).show();
             //   update(number);
                }
            }
        }
    }

}
