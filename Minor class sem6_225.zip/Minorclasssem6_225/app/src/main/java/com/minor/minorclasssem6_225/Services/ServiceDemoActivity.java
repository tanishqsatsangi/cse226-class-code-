package com.minor.minorclasssem6_225.Services;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.minor.minorclasssem6_225.R;

public class ServiceDemoActivity extends AppCompatActivity {
        Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_demo);
    b1=findViewById(R.id.btn1s);
    b2=findViewById(R.id.btn2s);

    b1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(ServiceDemoActivity.this,MyService1.class);
            startService(i);
        }
    });
    b2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(ServiceDemoActivity.this,MyService1.class);
            stopService(i);
        }
    });


    }
}
