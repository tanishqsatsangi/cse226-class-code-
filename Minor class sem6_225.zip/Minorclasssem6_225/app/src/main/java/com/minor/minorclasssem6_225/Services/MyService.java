package com.minor.minorclasssem6_225.Services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.minor.minorclasssem6_225.R;
import com.minor.minorclasssem6_225.Unit1.MainActivity;

public class MyService extends Service {
    NotificationManager notificationManager;
    MediaPlayer mediaPlayer;
    static final String update_notif="monprcclassnotifupdate";
    static final String startservice="Service started";
    static final String stopservice="Service Stopped";
    static final String my_Tag="service Demo";
    static final String channelid="primarynotifchannel";
    static final int notifid=0;
        int current=0;

    public MyService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer=MediaPlayer.create(this,R.raw.song);
        mediaPlayer.setLooping(false);
        notificationManager=getSystemService(NotificationManager.class);



    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        createnotif();
        String s=intent.getAction();
        if(s.equals(startservice)){

        }
        if(s.equals(stopservice)){

        }


        return START_STICKY;

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        deletenotif();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return  null;
    }

    public void createnotif(){

        Intent updateintent=new Intent(update_notif);
        PendingIntent creatependingintent=PendingIntent.getBroadcast(this,notifid,updateintent,PendingIntent.FLAG_ONE_SHOT);
        NotificationCompat.Builder notifbuilder= getNotifcationBuidler();
        notifbuilder.addAction(R.drawable.ic_launcher_foreground,"Notif",creatependingintent);
        notificationManager.notify(notifid,notifbuilder.build());
    }

    private NotificationCompat.Builder getNotifcationBuidler(){
        Intent notifintent=new Intent(this, MainActivity.class);
        PendingIntent notifpending=PendingIntent.getActivity(this,notifid,notifintent,PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder nbuilder=new NotificationCompat.Builder(this,channelid).setContentTitle("notif u").setContentText("thanku")
                .setSmallIcon(R.drawable.ic_launcher_background).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL).setContentIntent(notifpending);

        return  nbuilder;
    }
    public void deletenotif() {
        notificationManager.cancel(notifid);
    }

    public  void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel notificationChannel=new NotificationChannel(channelid,"Service notif",NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setDescription("Notif in Service");
            notificationManager.createNotificationChannel(notificationChannel);
        }

    }



}
