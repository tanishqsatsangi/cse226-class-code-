package com.minor.minorclasssem6_225.background;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.minor.minorclasssem6_225.R;

import java.util.ArrayList;

public class ListAsync extends AppCompatActivity {


    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_async);
    listView=findViewById(R.id.listview);

    new Async().execute();
    }

    class  Async extends AsyncTask<Void,Integer,String>{
        ArrayList<Integer> al=new ArrayList<>();
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(ListAsync.this, "Starting", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(ListAsync.this, ""+s, Toast.LENGTH_SHORT).show();
        }


        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            ArrayAdapter<Integer> arrayAdapter=new ArrayAdapter<>(ListAsync.this,android.R.layout.simple_list_item_1,al);
            listView.setAdapter(arrayAdapter);

        }

        @Override
        protected String doInBackground(Void... voids) {
          for(int i=0;i<20;i++){
              try {
                  Thread.sleep(1000);
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }
              al.add(i);
                publishProgress(i);
          }
            return "all added";
        }
    }
}
