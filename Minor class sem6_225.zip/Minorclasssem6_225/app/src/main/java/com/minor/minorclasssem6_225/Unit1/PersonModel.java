package com.minor.minorclasssem6_225.Unit1;

public class PersonModel {
    String name;
    String description;
    int img;

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImg() {
        return img;
    }

    public PersonModel(String name, String description, int img) {
        this.name = name;
        this.description = description;
        this.img = img;
    }
}
