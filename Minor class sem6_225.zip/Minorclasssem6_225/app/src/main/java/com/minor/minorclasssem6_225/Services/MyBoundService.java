package com.minor.minorclasssem6_225.Services;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public class MyBoundService extends Service {
    IBinder iBinder=new MyBinder();

    public MyBoundService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return  iBinder;
    }
    class MyBinder extends Binder{
        MyBoundService getService(){
            return new MyBoundService();
        }
    }

    public  String mymsg1(){
        return "mymsg1";

    }
}
